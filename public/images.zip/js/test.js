const nameInput = document.querySelector('.name-input');
const nextButton = document.querySelector('.submit-button');
// const nextQuestion = document.querySelector('#next');
const questionContainer = document.querySelector('.event-main-question');
const nameContainer = document.querySelector('.event-main-intro');
const birthdaycontainer = document.querySelector('.event-main-birthday');
const answerContainer = document.querySelectorAll('.question');
const scoreContainer = document.querySelector('.score p');


const quiz= [{
    question: "What is The language used in Embedded software",
    answers:["C","English","Spanish","Franco"],
    correct:"C"
},
    {
        question: "Printf in c language is used for:",
        answers:["preform complicated code","print the line in the console","do math calculations","Do nothing"],
        correct:"print the line in the console"
    },

    {
        question: "Which of the following is not object oriented language",
        answers:["C","JAVA","PYTHON","SWIFT"],
        correct:"C"
    }

];
let maxindex = quiz.length - 1;
let currentindex = 0;
let score = 0;
updateScore();

nextButton.addEventListener('click',e=>{
    check_name(nameInput.value);
})




answerContainer.forEach(element =>{
    element.addEventListener('click',e=>{
        const selectedAnswer = e.target.closest('.answer-text').textContent;

       if (!check_answer(selectedAnswer)){
           e.target.closest('.question').style.backgroundColor = "red";
           // currentindex++;

           setTimeout(function (){

               nextQuestion();

           },500)

       }else {
           e.target.closest('.question').style.backgroundColor = "green";
           score++;
           // updateScore();
           // currentindex++;
           setTimeout(function (){

                   nextQuestion();

           },500)
       }
    })
})



function check_answer(userAnswer){
    if (currentindex > maxindex){
        console.log(currentindex)
        return false
    }

       let correctAnswer = quiz[currentindex].correct;
    console.log("check",correctAnswer , userAnswer);
    if (userAnswer === correctAnswer){
        console.log("allah yenwar")
        return true

    }else {
        return false;
    }
}
function updateScore(){
    scoreContainer.textContent = `Score:${score}/${quiz.length}`
}


function check_name(answer){

    if (answer.toLowerCase() === 'habiba'){
        questionContainer.classList.remove("hide");
        startQuiz();
    }
}

function startQuiz(){

    questionContainer.querySelector('.question-title').textContent = quiz[currentindex].question;
    questionContainer.querySelectorAll('.answer-text').forEach((answer,index) =>{
        answer.textContent = quiz[currentindex].answers[index];
    })

}

function nextQuestion(){
    if (currentindex+1 > maxindex){
        exitQuiz()
        return
    }else {
        updateScore();
        currentindex++;
    }

        answerContainer.forEach(element =>{
            element.style.backgroundColor = ""
        })
        questionContainer.querySelector('.question-title').textContent = quiz[currentindex].question;
        questionContainer.querySelectorAll('.answer-text').forEach((answer,index) =>{
            answer.textContent = quiz[currentindex].answers[index];
        })

}

function exitQuiz(){
nameContainer.classList.add('hide');
    questionContainer.classList.add('hide');
    birthdaycontainer.classList.remove('hide')

}
