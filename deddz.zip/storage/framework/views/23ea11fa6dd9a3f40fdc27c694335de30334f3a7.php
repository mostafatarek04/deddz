<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

    <title> Deddz Activities</title>
</head>
<body>
<header>
    <div class="activity-header">
       <div class="activity-title-box">
           <h2>BRowse all our activities</h2>
       </div>
    </div>
</header>
<main>
    <section class="section-1">

        <div class="activities-search flex">
            <label for="user">Filter by user</label>
            <select name="user" id="user">
                <option value="" selected disabled hidden>Select Here</option>

              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->name); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>
        <div class="activities-main">
            <div class="">
                <div class="">


                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="activity back-1">
                            <div class="activity-hover">
                           <?php if(in_array($activity->id,$allSubs)): ?>
                               <div class="activity-hover-controls">
                                   <p>You are subscribed</p>
                                   <button data-id="<?php echo e($activity->id); ?>" id="Unsub">Unsubscribe</button>
                               </div>

                                <?php else: ?>

                                    <div class="activity-hover-controls">
                                        <p>You are not subscribed</p>
                                        <button data-id="<?php echo e($activity->id); ?>" id="Sub">Subscribe</button>
                                    </div>

                                <?php endif; ?>
                            </div>
                            <?php $__currentLoopData = $activity->subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><?php echo e($subscriber->pivot->use_name); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <div class="user-info">
                               <img src="<?php echo e(asset($activity->user->profile_photo_url)); ?>" alt="">
                               <h3><?php echo e($activity->user->name); ?></h3>
                           </div>
                            <h4 class="activity-entry"><?php echo e($activity->activity_title); ?></h4>
                            <p class="activity-entry"><?php echo e($activity->activity_body); ?></p>
                            <h5 class="activity-entry"><?php echo e($activity->published_at); ?></h5>
                            <h6 class="activity-entry">Confirmed:</h6>
                            <div class="users-container class=activity-entry">
                                <?php $__currentLoopData = $activity->subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div><img src="<?php echo e($subscriber2->pivot->user_img); ?>" alt=""></div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <a  href="">View Details</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

            </div>
        </div>
    </section>
</main>
<script src="<?php echo e(asset('js/activity.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Dedzz\resources\views/activities.blade.php ENDPATH**/ ?>