<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">

    <title>Deedzz Register</title>
</head>
<body>
<main>
<section class="section-signup">
    <div class="form-div">
        <h3 class="form-title text-cente">Sign in to our Deddz</h3>
        <?php echo Form::open(['url'=>'/user-login','method'=>'POST','class'=>'form']); ?>


        <div class="form-group">
            <?php echo Form::email('email',null,['placeholder'=>'Type Email Here ...','class'=>'form-group-input']); ?>

            <?php echo Form::label('email','Email Address',['class'=>'form-group-label']); ?>


        </div>
        <div class="form-group">
            <?php echo Form::password('password',['placeholder'=>'Type password Here ...','class'=>'form-group-input']); ?>

            <?php echo Form::label('password','Password',['class'=>'form-group-label']); ?>


        </div>


        <div class="form-group">
            <?php echo Form::submit('Sign In' ,['class'=>'form-group-submit']); ?>

        </div>
        <div class="signup-links text-cente">
            <a href="/signup">Not a user? Register Now</a>
        </div>

    </div>

</section>
</main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Dedzz\resources\views/Login.blade.php ENDPATH**/ ?>