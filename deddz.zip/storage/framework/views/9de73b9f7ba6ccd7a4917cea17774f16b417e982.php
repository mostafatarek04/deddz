<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<header class="stories-header">
        <div class="header-stories">
            <h3>Time to share our thoughts </h3>
        </div>

</header>

<main>

    <section class="stories-main">
        <div class="search-div">
            <?php echo Form::open(['url'=>'/stories','method'=>'get','class'=>'search-form']); ?>

            <?php echo Form::label('search','<i class="fa-solid fa-magnifying-glass"></i>',['class'=>'search-form-label'],false); ?>

            <?php echo Form::text('search',"",['class'=>'search-form-input','placeholder'=>'Enter Search keywords...']); ?>

            <?php echo Form::submit('Search',['class'=>'submit']); ?>

            <?php echo Form::close(); ?>

        </div>
        <div class="all-stories-container">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="all-stories-container-child">
                    <div class="user-info">
                        <img class="profile-photo" src="<?php echo e(asset($story->user->profile_photo_url)); ?>" alt="">
                        <h4><?php echo e($story->user->name); ?></h4></div>
                    <p><?php echo e($story->story); ?></p>
                    <p><?php echo e($story->published_at); ?></p>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </section>
</main>
<script src="<?php echo e(asset('js/story.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Dedzz\resources\views/stories.blade.php ENDPATH**/ ?>