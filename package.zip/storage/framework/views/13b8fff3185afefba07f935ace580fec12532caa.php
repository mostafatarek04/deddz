<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('favicon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;0,900;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('css/test.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">
    <title>Event</title>
</head>
<body>
<section class="event-section">
    <div class="event-main">

        <div class="event-main-intro">
            <h3 class="question-title">Whats Your name ?</h3>
            <input type="text" name="name" class="name-input" placeholder="Type Your name here " id="name-input">
            <label class="name-label" autocomplete="off" for="name-input">First name</label>
            <button class="submit-button">NEXT &rarr;</button>
        </div>
        <div class="event-main-question hide">
            <div class="score">
                <p>score:0/5</p>
            </div>
            <h3 class="question-title">Whats Your name ?</h3>
            <div class="question"><span>1.</span><p class="answer-text">answer 1</p></div>
            <div class="question"><span>2.</span><p class="answer-text">answer 2</p></div>
            <div class="question"><span>3.</span><p class="answer-text">answer 3</p></div>
            <div class="question"><span>4.</span><p class="answer-text">answer 4</p></div>
            <button class="submit-button" id="next">NEXT &rarr;</button>

        </div>
        <div class="event-main-birthday hide">
                  <p> Happpy birthday bobbb <i class="fa-solid fa-cake-candles"></i> </p>
        </div>
    </div>

</section>

<script src="<?php echo e(asset('js/test.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Dedzz\resources\views/test.blade.php ENDPATH**/ ?>