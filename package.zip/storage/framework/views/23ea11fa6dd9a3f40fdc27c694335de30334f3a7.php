<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <title> Deddz Activities</title>
</head>
<body>
<header>
    <div class="activity-header">
       <div class="activity-title-box">
           <h2>BRowse all our activities</h2>
       </div>
    </div>
</header>
<main>
    <section class="section-1">

        <div class="activities-main">
            <div class="row">
                <div class="col-3-of-4 margin-rt-small">

                            <div class="activity back-1">
                                <h4 class="activity-entry">Goo some where</h4>
                                <p class="activity-entry">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, nobis!</p>
                                <h5 class="activity-entry">12-03-2022</h5>
                                 <h6 class="activity-entry">Confirmed:</h6>
                                <div class="users-container class=activity-entry">
                                    <div><img src="images/nour.jpg" alt=""></div>
                                    <div><img src="images/mayar.jpg" alt=""></div>
                                    <div><img src="images/rana.jpg" alt=""></div>
                                </div>
                                <a  href="">View Details</a>
                            </div>
                            <div class="activity back-2">
                                <h4 class="activity-entry">Goo some where</h4>
                                <p class="activity-entry">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, nobis!</p>
                                <h5 class="activity-entry">12-03-2022</h5>
                                <h6 class="activity-entry">Confirmed:</h6>
                                <div class="users-container class=activity-entry">
                                    <div><img src="images/nour.jpg" alt=""></div>
                                    <div><img src="images/mayar.jpg" alt=""></div>
                                    <div><img src="images/rana.jpg" alt=""></div>
                                </div>
                                <a href="">View Details</a>
                            </div>
                            <div class="activity back-3">
                                <h4 class="activity-entry">Goo some where</h4>
                                <p class="activity-entry">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, nobis!</p>
                                <h5 class="activity-entry">12-03-2022</h5>
                                <h6 class="activity-entry">Confirmed:</h6>
                                <div class="users-container class=activity-entry">
                                    <div><img src="images/nour.jpg" alt=""></div>
                                    <div><img src="images/mayar.jpg" alt=""></div>
                                    <div><img src="images/rana.jpg" alt=""></div>
                                </div>
                                <a href="">View Details</a>
                            </div>
                            <div class="activity back-2">
                        <h4 class="activity-entry">Goo some where</h4>
                        <p class="activity-entry">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, nobis!</p>
                        <h5 class="activity-entry">12-03-2022</h5>
                        <h6 class="activity-entry">Confirmed:</h6>
                        <div class="users-container class=activity-entry">
                            <div><img src="images/nour.jpg" alt=""></div>
                            <div><img src="images/mayar.jpg" alt=""></div>
                            <div><img src="images/rana.jpg" alt=""></div>
                        </div>
                        <a href="">View Details</a>
                    </div>
                            <div class="activity back-2">
                        <h4 class="activity-entry">Goo some where</h4>
                        <p class="activity-entry">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, nobis!</p>
                        <h5 class="activity-entry">12-03-2022</h5>
                        <h6 class="activity-entry">Confirmed:</h6>
                        <div class="users-container class=activity-entry">
                            <div><img src="images/nour.jpg" alt=""></div>
                            <div><img src="images/mayar.jpg" alt=""></div>
                            <div><img src="images/rana.jpg" alt=""></div>
                        </div>
                        <a href="">View Details</a>
                    </div>
                            <div class="activity back-4">
                        <h4 class="activity-entry">Goo some where</h4>
                        <p class="activity-entry">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, nobis!</p>
                        <h5 class="activity-entry">12-03-2022</h5>
                        <h6 class="activity-entry">Confirmed:</h6>
                        <div class="users-container class=activity-entry">
                            <div><img src="images/nour.jpg" alt=""></div>
                            <div><img src="images/mayar.jpg" alt=""></div>
                            <div><img src="images/rana.jpg" alt=""></div>
                        </div>
                        <a href="">View Details</a>
                    </div>
                            <div class="activity back-4">
                        <h4 class="activity-entry">Goo some where</h4>
                        <p class="activity-entry">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, nobis!</p>
                        <h5 class="activity-entry">12-03-2022</h5>
                        <h6 class="activity-entry">Confirmed:</h6>
                        <div class="users-container class=activity-entry">
                            <div><img src="images/nour.jpg" alt=""></div>
                            <div><img src="images/mayar.jpg" alt=""></div>
                            <div><img src="images/rana.jpg" alt=""></div>
                        </div>
                        <a href="">View Details</a>
                    </div>

                           <div class="activity back-6">
                        <h4 class="activity-entry">Goo some where</h4>
                        <p class="activity-entry">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, nobis!</p>
                        <h5 class="activity-entry">12-03-2022</h5>
                        <h6 class="activity-entry">Confirmed:</h6>
                        <div class="users-container class=activity-entry">
                            <div><img src="images/nour.jpg" alt=""></div>
                            <div><img src="images/mayar.jpg" alt=""></div>
                            <div><img src="images/rana.jpg" alt=""></div>
                        </div>
                        <a href="">View Details</a>
                    </div>


                </div>
                <div class="col-1-of-4">
                    <div class="legend">
                        <h4 class="text-cente">Activities Legend</h4>
                        <div class="legend-row">
                           <div class="color1 color-box"></div>
                           <div class="name-info">Rana Adel</div>
                        </div>
                        <div class="legend-row">
                            <div class="color2 color-box"></div>
                            <div class="name-info">Nour Adel</div>
                        </div>
                        <div class="legend-row">
                            <div class="color3 color-box"></div>
                            <div class="name-info">Habiba Adel</div>
                        </div>
                        <div class="legend-row">
                            <div class="color4 color-box"></div>
                            <div class="name-info">Mostafa Tarek</div>
                        </div>
                        <div class="legend-row">
                            <div class="color6 color-box"></div>
                            <div class="name-info">Mayar Tarek</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Dedzz\resources\views/activities.blade.php ENDPATH**/ ?>