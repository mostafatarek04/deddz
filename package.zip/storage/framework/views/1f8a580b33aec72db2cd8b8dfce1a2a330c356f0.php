<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">

    <title>Deedzz Register</title>
</head>
<body>
<main>
<section class="form-section">




    <?php echo Form::open(['url'=>'/user','method'=>'POST','class'=>'form']); ?>

    <h3>Register And join THE DEDDDZZZ!</h3>

  <div class="input-group">
      <?php echo Form::label('Name','<i class="fa-solid fa-id-card"></i>',['class'=>'form-label'],false); ?>

      <div class="seperator"></div>
      <?php echo Form::text('Name',null,['placeholder'=>'Full name here...','class'=>'form-input']); ?>

  </div>

   <div class="input-group">
       <?php echo Form::label('nickName','<i class="fa-solid fa-face-smile"></i>',['class'=>'form-label'],false); ?>

       <div class="seperator"></div>

       <?php echo Form::text('nickName',null,['placeholder'=>'Nickname here...','class'=>'form-input']); ?>


   </div>

    <div class="input-group">
        <?php echo Form::label('dateofbirth','<i class="fa-solid fa-calendar"></i>',['class'=>'form-label'],false); ?>

        <div class="seperator"></div>

        <?php echo Form::date('dateofbirth',\Carbon\Carbon::now()->year(1990)->day(1)->month(1)); ?>


    </div>


    <div class="input-group">
        <?php echo Form::label('gender','<i class="fa-solid fa-venus-mars"></i>',['class'=>'form-label'],false); ?>

        <div class="seperator"></div>

        <?php echo Form::radio('_gender','Male-name',false,['class'=>'']); ?>

        <?php echo Form::label('_gender','Male',['class'=>'']); ?>




        <?php echo Form::radio('_gender','Female',false,['class'=>'']); ?>

        <?php echo Form::label('_gender','Female',['class'=>'']); ?>


    </div>


        <?php echo Form::button('Register',['class'=>'form-btn','type'=>'submit']); ?>



</section>
</main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Dedzz\resources\views/Login.blade.php ENDPATH**/ ?>