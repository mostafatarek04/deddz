@extends('layouts.profile-layout')

@section('profile-side')

<div class="profile-controls">
    <div class="profile-controls-pic-box">
        <img src="{{asset('images/mostafa.jpeg')}}" alt="">
    </div>
    <div class="profile-controls-name">
        <h3 class="profile-name"><span class="upper">Mostafa Tarek</span><span class="bottom">Site Administrator</span></h3>

    </div>
    <div class="profile-controls-links">
        <ul>
            <li>Profile Info</li>
            <li>Activities</li>
            <li>Friends</li>
            <li>Logout</li>
        </ul>
    </div>
</div>

@endsection


@section('profile-main')
<div class="profile-info">
    <div class="profile-info-basic">
        <h3 class="profile-title entry">Basic Info</h3>
        <h6 class="entry"><span>Name: </span><span>Mostafa Tarek Mohamed </span></h6>
        <h6 class="entry"><span>Date of Birth: </span><span>13/02/1994</span></h6>
    </div>

    <div class="profile-info-additional">
        <h3 class="profile-title">Basic Info</h3>
        <h6><span>Name: </span><span>Mostafa Tarek Mohamed </span></h6>
        <h6><span>Date of Birth: </span><span>13/02/1994</span></h6>

    </div>
   </div>
@endsection
